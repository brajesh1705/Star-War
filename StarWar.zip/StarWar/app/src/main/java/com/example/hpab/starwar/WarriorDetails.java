package com.example.hpab.starwar;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.provider.SyncStateContract;

/**
 * Created by Brajesh Kumar on 16-01-2016.
 */
public class WarriorDetails {
    private int id;
    private String Name;
    private String Warrior_Afflication;
    private String Gender;
    private String Species;
    private String Warrior_LSO;
    private String Warrior_LKP;
    private String Warrior_Image;

    public WarriorDetails(){

    }
    public WarriorDetails(int id, String name, String warrior_Afflication, String gender, String species, String warrior_LSO, String warrior_LKP, String warrior_Image) {
        this.id = id;
        Name = name;
        Warrior_Afflication = warrior_Afflication;
        Gender = gender;
        Species = species;
        Warrior_LSO = warrior_LSO;
        Warrior_LKP = warrior_LKP;
        Warrior_Image = warrior_Image;
    }



    public String getSpecies() {
        return Species;
    }

    public void setSpecies(String species) {
        Species = species;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getWarrior_Afflication() {
        return Warrior_Afflication;
    }

    public void setWarrior_Afflication(String warrior_Afflication) {
        Warrior_Afflication = warrior_Afflication;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getWarrior_LSO() {
        return Warrior_LSO;
    }

    public void setWarrior_LSO(String warrior_LSO) {
        Warrior_LSO = warrior_LSO;
    }

    public String getWarrior_LKP() {
        return Warrior_LKP;
    }

    public void setWarrior_LKP(String warrior_LKP) {
        Warrior_LKP = warrior_LKP;
    }

    public String getWarrior_Image() {
        return Warrior_Image;
    }

    public void setWarrior_Image(String warrior_Image) {
        Warrior_Image = warrior_Image;
    }

    public boolean hasImage() {

        return getWarrior_Image() != null && !getWarrior_Image().isEmpty();
    }
    public Drawable getThumbnail(Context context) {

        return getScaledImage(context, 128, 128);
    }
    public Drawable getImage(Context context) {

        return getScaledImage(context, 512, 512);
    }
    private Drawable getScaledImage(Context context, int reqWidth, int reqHeight) {

        // If profile has a Image.
        if (hasImage()) {

            // Decode the input stream into a bitmap.
            Bitmap bitmap = FileUtils.getResizedBitmap(getWarrior_Image(), reqWidth, reqHeight);

            // If was successfully created.
            if (bitmap != null) {

                // Return a drawable representation of the bitmap.
                return new BitmapDrawable(context.getResources(), bitmap);
            }
        }

        // Return the default image drawable.
        return context.getResources().getDrawable(R.drawable.download);
    }
}
