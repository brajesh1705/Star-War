package com.example.hpab.starwar;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Brajesh Kumar on 08-01-2016.
 */
public class Database extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "STARWAR_DB.db";
    public static final String TABLE_NAME = "Warrior_table";
    public static final String ID = "ID";
    public static final String W_NAME = "Name";
    public static final String W_AFFLICATION = "Warrior_Afflication";
    public static final String W_SPECIES = "Warrior_Species";
    public static final String W_GENDER = "Warrior_Gender";
    public static final String W_LSO = "Warrior_LSO";
    public static final String W_LKP = "Warrior_LKP";
    public static final String mImagePath = "Warrior_Image";

    public Database(Context context) {

        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT,Name TEXT,Warrior_Afflication TEXT,Warrior_Species TEXT,Warrior_Gender TEXT,Warrior_LSO TEXT,Warrior_LKP TEXT,Warrior_Image TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean insertData(WarriorDetails wd) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(W_NAME, wd.getName());
        contentValues.put(W_AFFLICATION, wd.getWarrior_Afflication());
        contentValues.put(W_SPECIES, wd.getSpecies());
        contentValues.put(W_GENDER, wd.getGender());
        contentValues.put(W_LSO, wd.getWarrior_LSO());
        contentValues.put(W_LKP, wd.getWarrior_LKP());
        contentValues.put(mImagePath, wd.getWarrior_Image());
        long result = db.insert(TABLE_NAME, null, contentValues);
        if (result == -1)
            return false;
        else
            return true;
    }

    public List<WarriorDetails> getAllData() {
        List<WarriorDetails> res = new ArrayList<WarriorDetails>();
        String query = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query,null);
        if (cursor.moveToFirst()) {
            do {
                WarriorDetails wd = new WarriorDetails();
                wd.setId(Integer.parseInt(cursor.getString(0)));
                wd.setName(cursor.getString(1));
                wd.setWarrior_Afflication(cursor.getString(2));
                wd.setSpecies(cursor.getString(3));
                wd.setGender(cursor.getString(4));
                wd.setWarrior_LSO(cursor.getString(5));
                wd.setWarrior_LKP(cursor.getString(6));
                wd.setWarrior_Image(cursor.getString(7));
                // Adding contact to list
                res.add(wd);
            } while (cursor.moveToNext());
        }
        return res;
    }
}
